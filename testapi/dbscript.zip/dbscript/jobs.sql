USE [dbJOBdata]
GO

/****** Object:  Table [dbo].[Jobs]    Script Date: 11-12-2022 20:57:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Jobs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[code] [varchar](50) NULL,
	[Title] [varchar](50) NULL,
	[Description] [varchar](50) NULL,
	[LocationId] [int] NULL,
	[departmentId] [int] NULL,
	[posteddate] [date] NULL,
	[closingdate] [date] NULL,
 CONSTRAINT [PK_Jobs_1] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

